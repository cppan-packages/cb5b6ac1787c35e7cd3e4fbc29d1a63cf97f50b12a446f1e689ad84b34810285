#pragma once

#include <evpp/exp.h>
#include "evnsq_export.h"
#include "consumer.h"

#ifdef H_OS_WINDOWS
H_LINK_LIB("evnsq_static")
#endif

